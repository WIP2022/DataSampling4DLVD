short add (short b) {
 short a = 32767;
 if (b > 0) {
 a = a + b;
 }
 return a;
 }