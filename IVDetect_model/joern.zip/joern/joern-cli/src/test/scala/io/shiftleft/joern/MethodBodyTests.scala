package io.shiftleft.joern

class MethodBodyTests {}
