[![Build Status](https://travis-ci.org/ShiftLeftSecurity/joern.svg?branch=master)](https://travis-ci.org/ShiftLeftSecurity/joern)

Documentation at: https://joern.io/docs/
