Ready-to-run scripts for Joern
===============================

This is our collection of ready-to-run scripts for `joern-query`. You can start them by issuing the command

```
joern-query -f scripts/$filename
```

Please send a PR if you have a nice script to share :)

