+++
title="Exploring Types"
weight=3
+++

{{<snippet file="src/test/scala/io/shiftleft/joern/TypeDeclTests.scala" language="scala">}}
