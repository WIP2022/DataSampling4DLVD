+++
title="Exploring Locals"
weight=4
+++

{{<snippet file="src/test/scala/io/shiftleft/joern/LocalsTests.scala" language="scala">}}
