+++
title="Exploring Methods"
weight=3
+++

{{<snippet file="src/test/scala/io/shiftleft/joern/MethodTests.scala" language="scala">}}
