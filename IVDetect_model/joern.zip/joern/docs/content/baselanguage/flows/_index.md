+++
title="Exploring Data Flows"
weight=6
+++

{{<snippet file="src/test/scala/io/shiftleft/joern/DataFlowTests.scala" language="scala">}}
