+++
title="Exploring Call Graphs"
weight=5
+++

{{<snippet file="src/test/scala/io/shiftleft/joern/CallGraphTests.scala" language="scala">}}
