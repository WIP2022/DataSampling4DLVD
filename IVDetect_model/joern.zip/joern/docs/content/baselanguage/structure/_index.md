+++
title="Exploring Program Structure"
weight=2
+++

{{<snippet file="src/test/scala/io/shiftleft/joern/StructureTests.scala" language="scala">}}
