+++
Title="Essentials"
weight=1
alwaysopen=true
+++

In this section, we review how Joern is installed, code property graphs can be created, and how they are queried.