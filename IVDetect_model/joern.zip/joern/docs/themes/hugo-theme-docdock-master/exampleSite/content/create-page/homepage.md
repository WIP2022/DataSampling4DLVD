+++
title = "Home page"
description = ""
date = "2017-04-28T18:36:24+02:00"
tags = ["tag1","tag2"]
+++

To tell Hugo-theme-docdock to consider a page as homepage's content, just create a content file named `_index.md` in content folder.
